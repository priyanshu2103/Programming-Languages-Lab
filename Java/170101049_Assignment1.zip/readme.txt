1. There are individual readme's for each program inside their folder, which contains description needed to run them.

2. The code is developed through openjdk version "1.8.0_265"