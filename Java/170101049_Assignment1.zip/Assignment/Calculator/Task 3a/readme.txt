1. Run the program using the following commands:

javac CalcDesign.java
java CalcDesign

2. A calculator window would popup that would start highlighting buttons with GREEN and YELLOW color for the user to select using the ENTER key. It's a very intuitive and user friendly calculator that does calculation on single digit integers.

3. Press key C to clear your output screen and "=" to find the result of the input expression.

