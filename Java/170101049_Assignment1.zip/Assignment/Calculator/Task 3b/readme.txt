1. Run the program using the following commands:

javac CalcDesign.java
java CalcDesign

2. A calculator window would popup that would start highlighting buttons with GREEN AND YELLOW color for the user to select. Keys highlighted by GREEN color are selected using ENTER key and keys highlighted by YELLOW color are selected using SPACE key. It's a very intuitive and user friendly calculator that does calculation on multi digit numbers.

3. Press key C to clear your output screen and "=" to find the result of the input expression.

